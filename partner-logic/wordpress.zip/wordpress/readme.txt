To integrate with WordPress installed on
http://www.example.com/wordpress/.

1. Upload gixawremote_phpbb3.php to /httpdocs/wordpress directory.
2. Create a new integration in Gixaw Chat Administration Area and provide the Integration URL as
   http://www.example.com/wordpress/gixawremote_wordpress.php
3. Click Download link against the Integration to download gixawremote.php file.
4. Upload gixawremote.php to /httpdocs/wordpress directory.