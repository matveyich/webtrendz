<?php
require_once('wp-load.php');
require_once(realpath(dirname(__FILE__)).DIRECTORY_SEPARATOR.'gixawremote.php');

$user = wp_get_current_user();
if (empty($user->ID)) {
	auth_redirect();
}
else {
	return_to_gixaw(array(
		'external_id' => $user->ID,
		'display_name' => $user->display_name,
		'group_name' => ucfirst(array_shift($user->roles)),
		'profile_email_address' => $user->email,
		'profile_full_name' => trim($user->first_name.' '. $user->last_name),
	));
}