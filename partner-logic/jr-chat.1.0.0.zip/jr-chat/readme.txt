=== Plugin Name ===
Contributors: Jake Ruston
Donate link: http://www.jakeruston.co.uk
Tags: java, chat, chatroom, chat room, post, plugin, IRC, mIRC, page, post, javascript
Requires at least: 2.0.2
Tested up to: 2.8.5
Stable tag: 1.0.0

This Chat plugin allows you to display your own Java chat room on your website so your users can chat with each other!

== Description ==

This Chat plugin allows you to display your own Java chat room on your website so your users can chat with each other!

Installation is very quick. Simply go into the Wordpress admin panel, Settings --> JR Chat. Choose a name for your Java chatroom and the dimensions of the applet which is to be displayed on your website. Then, enter [jr_chat] in a page or post. This is where the chatroom will be shown.

== Installation ==

1. Upload `jr-chat.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the JR Chat Settings in your Administration Panel
4. Enter [jr_chat] in a page or post to show the Java chatroom.

== Frequently Asked Questions ==

= Does this work? =

Yes.

== Changelog ==

= 1.0 =
* Initial Release
