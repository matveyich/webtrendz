<div>
<label for="cht_title">Title</label><br/>
<input type="text" name="cht_title" value="<?php echo $cht_title; ?>" id="cht_title" />
</div><div>
<label for="cht_border_thickness">Border Thickness</label><br/>
<input type="text" name="cht_border_thickness" value="<?php echo $cht_border_thickness; ?>" id="cht_border_thickness" /> px
</div><div>
<label for="cht_border_color">Border Color</label><br/>
#<input type="text" name="cht_border_color" value="<?php echo $cht_border_color; ?>" id="cht_border_color" />
</div><div>
<label for="cht_border_radius">Border Radius</label><br/>
<input type="text" name="cht_border_radius" value="<?php echo $cht_border_radius; ?>" id="cht_border_radius" />px
</div>