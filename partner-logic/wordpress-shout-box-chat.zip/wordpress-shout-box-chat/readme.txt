=== Wordpress Shout Box / Chat ===
Contributors: Shaon
Donate link: 
Tags: wordpress plugin, shoutbox, chat, wp chat, widget, sidebar, user communication, visitor chat
Requires at least: 2.0.2
Tested up to: 2.9.2
Stable tag: 4.3

This plugin can be used to communicate among the online visitor on a wordpress site


== Description ==

This plugin can be used to communicate among the online visitor on a wordpress site. Simple use `WP Chat` widget from your widgets. If your theme is not widget ready then use `<?php wp_chat(); ?>` anywhere in sidebar you want to place chat box.


== Installation ==

   1. Upload `wordpress-shout-box-chat` to the `/wp-content/plugins/`  directory
   2. Activate the plugin through the 'Plugins' menu in WordPress
   3. Goto Widget menu and simply drag and drop "WP Chat" on your sidebar. If your theme is not widget ready then use `&lt;?php wp_chat(); ?&gt;` anywhere in sidebar you want to place chat box.


== Frequently Asked Questions ==
N/A

== Screenshots ==
N/A

== Changelog ==

= 1.4 = 
* `wp_chat()` function added

= 1.2 =
* Minor style adjustment
* Session issue fixed

= 1.1 =
* Fixed broken JS path issue

= 1.0 =
* Initial Release


== Arbitrary section ==
N/A

== Upgrade Notice ==
N/A