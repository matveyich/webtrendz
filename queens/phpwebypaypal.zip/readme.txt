**************************************************************************
*  If you like this software please link to us!                          *
*  Use this code:							 *
*  <a href="http://phpweby.com/software/php-paypal">PHP Paypal</a>    *
*  More info can be found at http://phpweby.com/link                     *
**************************************************************************                  

 Free PHP paypal Class

 Free simple PHP class for PayPal payments with IPN (instant payment notification) validation that allows you to enable  subscriptions or one-time payments. Supports adding/removing variables so you can further customize your payment (e.g enable  trial period for your product), payment form output and logging.

Please visit http://phpweby.com/software/php-paypal for more info
